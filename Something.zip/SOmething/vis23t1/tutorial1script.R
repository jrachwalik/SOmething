library(modelr)
library(kableExtra)
library(ggplot2)
library(ggthemes)
library(dplyr)
library(knitr)
library(nycflights13)
library(forcats)
library(tidyverse)

smallpox <- read.csv("GlobalSmallpoxCases.csv",
                                       header = TRUE)

head(smallpox)

names(smallpox)

names(smallpox)[4] <- "cases"


smallpox <- smallpox[,-2]


smallpox$cases

mean(smallpox$cases)

median(smallpox$cases)


median(heights$weight[heights$height == 69], na.rm=TRUE)
